# MuJoConv
Yes, this is used to convert URDF file to MJCF file.
Thanks!
